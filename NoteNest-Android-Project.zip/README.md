# NoteNest Android

Offline-first NoteNest notes and drawing app. Notes are saved in local device storage. Internet is only needed to build the APK with GitHub Actions.

## Build APK
Push this project to the `main` branch of GitHub. The workflow under `.github/workflows/build-apk.yml` builds a debug APK. Open the repository's Actions tab, select `Build NoteNest APK`, and download the `NoteNest-APK` artifact.
